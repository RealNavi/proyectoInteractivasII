<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TbReminder extends Model
{
    protected $fillable = [
        'title',
        'icon',
        'description',
        'location',
        'date',
        'time',
        'repeat',
        'profile_id',
    ];

    //Esta funcion relaciona la tabla tb_reminders con la tabla tb_profiles
    public function profile()
    {
        return $this->belongsTo(TbProfile::class);
    }

    public function notification(){
        return $this->hasMany(TbNotification::class);
    }
}
