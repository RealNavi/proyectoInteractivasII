<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TbProfile extends Model
{
    protected $fillable = [
        'cedula',
        'nombre_usuario',
        'nombre',
        'primer_apellido',
        'segundo_apellido',
        'email'
    ];
    
    //Esta funcion relaciona la tabla tb_profiles con la tabla tb_reminders
    public function reminder()
    {
        return $this->hasMany(TbReminder::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function medication()
    {
        return $this->hasMany(TbMedication::class);
    }

    public function medical_record()
    {
        return $this->hasOne(TbMedicalRecord::class);
    }

    public function notification()
    {
        return $this->hasMany(TbNotification::class);
    }

}
