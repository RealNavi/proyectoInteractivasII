<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TbMedicalRecord extends Model
{
    protected $fillable = [
        'cedula',
        'birthdate',
        'gender',
        'marital_status',
        'address',
        'phone',
        'emergency_contact-number',
        'occupation',
        'other_information',
        'vaccination',
        'allergies',
        'gynecological_history',
        'family_medical_history'
    ];

    public function profile()
    {
        return $this->belongsTo(TbProfile::class);
    }
}
