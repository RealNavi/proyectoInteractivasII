<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TbMedication extends Model
{
    protected $fillable = [
        'name',
        'dosage',
        'lab',
        'profile_id',
    ];

    public function profile()
    {
        return $this->belongsTo(TbProfile::class);
    }
}
