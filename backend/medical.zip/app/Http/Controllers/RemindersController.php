<?php

namespace App\Http\Controllers;

use App\Models\TbReminder;

use Illuminate\Http\Request;

class RemindersController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $date = $request->query('date');
        $query = TbReminder::query();

        if ($date) {
            $query->where('date', $date);
        }   

        $reminders = $query->get();

        return response()->json($reminders);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //No se va a estar implementando utilizando blade, se va a estar utilizando API
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:100|min:3',
            'icon' => 'required|string|max:50',
            'description'=> 'required|string|min:3',
            'location'=> 'nullable|string|max:150',
            'date'=> 'required|date',
            'time'=> 'required|date_format:H:i',
            'repeat'=> 'boolean',
            'profile_id'=> 'required|exists:tb_profiles,cedula',
        ]);

        $reminder = TbReminder::create($validated);

        return response()->json($reminder, 201);
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //En la aplicación no se mostrará un reminder en particular, solo por lista, entonces no se implementara
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //De momento, no se va a estar implementando el editar recordatorios
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //De momento, no se va a estar implementando el actualizar recordatorios
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //De momento, no se va a estar implementando el eliminar recordatorios
    }

    
}
