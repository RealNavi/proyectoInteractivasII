<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('tb_notifications', function (Blueprint $table) {
            $table->id();
            $table->datetime('date');
            $table->foreignId('reminder_id')->constrained('tb_reminders')->onDelete('cascade');
            $table->string('profile_id', 20);
            $table->foreign('profile_id')->references('cedula')->on('tb_profiles')->onDelete('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('tb_notifications');
    }
};
