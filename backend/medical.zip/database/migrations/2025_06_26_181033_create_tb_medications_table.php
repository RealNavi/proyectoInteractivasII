<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('tb_medications', function (Blueprint $table) {
            $table->id();
            $table->string('name', 100);
            $table->string('dosage', 100);
            $table->string('lab', 100);
            $table->string('profile_id', 20);
            $table->foreign('profile_id')->references('cedula')->on('tb_profiles')->onDelete('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('tb_medications');
    }
};
